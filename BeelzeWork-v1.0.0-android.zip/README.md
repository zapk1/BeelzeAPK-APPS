# BeelzeWork

Package: `com.beelze.beelzework`
Version: 1.0.0 (1)
Source: https://beelzechat.co.za

## Get the APK

Option 1 — GitHub Actions (no Mac or Android Studio needed)
1. Create a GitHub repository and upload this folder.
2. Open the Actions tab and run "Build APK".
3. Download the app-debug-apk artifact. That is your installable APK.

Option 2 — Android Studio
1. Open this folder in Android Studio.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. Find the APK in app/build/outputs/apk/debug/.
