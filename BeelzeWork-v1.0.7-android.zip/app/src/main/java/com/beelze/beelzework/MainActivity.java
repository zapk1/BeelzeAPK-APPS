package com.beelze.beelzework;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final String START_URL = "https://beelzework.beelzeapps.co.za";
    private static final String HOME_HOST = "beelzework.beelzeapps.co.za";
    private static final String LOADING_STYLE = "spinner";
    private static final String BG_COLOR = "#FFFFFF";
    private static final int FILE_PICK = 9001;

    private WebView web;
    private FrameLayout splash;
    private ProgressBar bar;
    private ValueCallback<Uri[]> filePathCallback;
    private long shownAt = 0;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int bg = parseColor(BG_COLOR);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(bg);

        web = new WebView(this);
        web.setBackgroundColor(bg);
        web.setLayoutParams(new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setGeolocationEnabled(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (HOME_HOST.isEmpty() || host == null) return false;
                if (host.equalsIgnoreCase(HOME_HOST) || host.endsWith("." + HOME_HOST)) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                hideSplash();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (bar != null) bar.setProgress(newProgress);
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override public void run() { request.grant(request.getResources()); }
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                cb.invoke(origin, true, false);
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                filePathCallback = cb;
                try {
                    Intent i = params.createIntent();
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(i, FILE_PICK);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
            }
        });

        root.addView(web);

        splash = buildSplash(bg);
        root.addView(splash);

        setContentView(root);
        shownAt = System.currentTimeMillis();

        requestRuntimePermissions();
        web.loadUrl(START_URL);
    }

    private int parseColor(String hex) {
        try { return Color.parseColor(hex); } catch (Exception e) { return Color.WHITE; }
    }

    private FrameLayout buildSplash(int bg) {
        FrameLayout box = new FrameLayout(this);
        box.setBackgroundColor(bg);
        box.setLayoutParams(new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        float dp = getResources().getDisplayMetrics().density;

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.gravity = Gravity.CENTER;
        center.setLayoutParams(cp);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams((int) (84 * dp), (int) (84 * dp));
        lp.bottomMargin = (int) (26 * dp);
        logo.setLayoutParams(lp);
        center.addView(logo);

        int ink = (bg == Color.WHITE) ? 0xFF0A0A0A : 0xFFFFFFFF;

        if ("dots".equals(LOADING_STYLE)) {
            center.addView(makeDots(ink));
        } else if ("gradient".equals(LOADING_STYLE)) {
            bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            bar.setMax(100);
            bar.setIndeterminate(false);
            GradientDrawable g = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[] { 0xFFEF4444, 0xFFF59E0B, 0xFF22C55E, 0xFF3B82F6, 0xFF8B5CF6 });
            g.setCornerRadius(50f);
            bar.setProgressDrawable(g);
            bar.setLayoutParams(new LinearLayout.LayoutParams((int) (150 * dp), (int) (8 * dp)));
            center.addView(bar);
        } else if ("spinner".equals(LOADING_STYLE)) {
            ProgressBar sp = new ProgressBar(this);
            sp.setIndeterminate(true);
            sp.setLayoutParams(new LinearLayout.LayoutParams((int) (36 * dp), (int) (36 * dp)));
            center.addView(sp);
        } else {
            TextView t = new TextView(this);
            t.setText("Loading");
            t.setTextSize(15f);
            t.setTextColor(ink);
            t.setGravity(Gravity.CENTER);
            center.addView(t);
        }

        box.addView(center);

        TextView brand = new TextView(this);
        brand.setText("powered by beelzeapps.co.za");
        brand.setTextSize(10f);
        brand.setTextColor(bg == Color.WHITE ? 0xFF9A9AA0 : 0x99FFFFFF);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        bp.bottomMargin = (int) (28 * dp);
        brand.setLayoutParams(bp);
        box.addView(brand);

        return box;
    }

    private LinearLayout makeDots(int ink) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        float dp = getResources().getDisplayMetrics().density;
        int d = (int) (9 * dp);
        for (int i = 0; i < 3; i++) {
            View dot = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(ink);
            dot.setBackground(g);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(d, d);
            lp.leftMargin = (int) (4 * dp);
            lp.rightMargin = (int) (4 * dp);
            dot.setLayoutParams(lp);
            dot.setAlpha(0.45f);
            final View target = dot;
            dot.postDelayed(new Runnable() {
                @Override public void run() { pulse(target); }
            }, i * 160);
            row.addView(dot);
        }
        return row;
    }

    private void pulse(final View v) {
        if (v == null) return;
        v.animate().alpha(1f).scaleX(1.15f).scaleY(1.15f).setDuration(280)
            .withEndAction(new Runnable() {
                @Override public void run() {
                    v.animate().alpha(0.45f).scaleX(1f).scaleY(1f).setDuration(280)
                        .withEndAction(new Runnable() {
                            @Override public void run() {
                                if (splash != null && splash.getVisibility() == View.VISIBLE) pulse(v);
                            }
                        }).start();
                }
            }).start();
    }

    private void hideSplash() {
        if (splash == null) return;
        long waited = System.currentTimeMillis() - shownAt;
        long left = Math.max(0, 1100 - waited);
        splash.postDelayed(new Runnable() {
            @Override public void run() {
                if (splash == null) return;
                splash.animate().alpha(0f).setDuration(320)
                    .withEndAction(new Runnable() {
                        @Override public void run() {
                            if (splash != null) splash.setVisibility(View.GONE);
                        }
                    }).start();
            }
        }, left);
    }

    private void requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT < 23) return;
        List<String> ask = new ArrayList<String>();
                String[] wanted = new String[] {

        };
        for (String p : wanted) {
            try {
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) ask.add(p);
            } catch (Exception ignored) { }
        }
        if (!ask.isEmpty()) requestPermissions(ask.toArray(new String[0]), 7001);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_PICK) {
            if (filePathCallback != null) {
                Uri[] out = null;
                if (res == RESULT_OK && data != null && data.getData() != null) {
                    out = new Uri[] { data.getData() };
                }
                filePathCallback.onReceiveValue(out);
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
